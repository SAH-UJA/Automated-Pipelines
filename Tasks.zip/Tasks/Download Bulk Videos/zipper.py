import shutil
def main():
	shutil.make_archive('zipped_videos', 'zip', 'output')