from __future__ import unicode_literals
import youtube_dl
from selenium import webdriver
import io
import os
import time
import requests
from PIL import Image
import hashlib
from moviepy.editor import *
import zipper
import mailer
from flask import *

app = Flask(__name__)

@app.route('/')
def home(message = " "):
	return render_template("index.html",message=message)

@app.route('/submitted', methods=['POST'])
def submitted():
	keyword = request.form['keyword']
	number = request.form['number']
	email = request.form['email']
	ydl_opts = {}

	sleep_between_interactions = 1

	DRIVER_PATH = "C:/Users/hp/Desktop/chromedriver.exe"
	wd = webdriver.Chrome(executable_path=DRIVER_PATH)
	def scroll_to_end(wd):
	        wd.execute_script("window.scrollTo(0, document.body.scrollHeight);")
	        time.sleep(sleep_between_interactions) 
	search_url = "https://www.google.com/search?q={q}&source=lmns&tbm=vid&safe=off&hl=en"
	wd.get(search_url.format(q=keyword))
	image_urls = set()
	image_count = 0
	results_start = 0
	total_images = int(number)

	while image_count < total_images:
		scroll_to_end(wd)
		thumbnail_results = wd.find_elements_by_css_selector("a.rGhul")
		number_results = len(thumbnail_results)
		results_start+=1
		print(f"Found: {number_results} search results. Extracting links from {results_start}:{number_results}")
		
		for i in thumbnail_results:
			image_urls.add(i.get_attribute('href'))

		image_count+=number_results
		if image_count<total_images:
			load_more_button = wd.find_element_by_css_selector("a.G0iuSb")
			time.sleep(sleep_between_interactions)
			load_more_button.click()
	wd.quit()
	image_urls = list(image_urls)
	print(image_urls[0:total_images])

	os.chdir('download')
	for i in image_urls[0:total_images]:
		with youtube_dl.YoutubeDL(ydl_opts) as ydl:
			ydl.download([i])
	os.chdir('..')
	
	lists = []
	for i in os.walk('download'):
		lists = i[2]
	j=1
	print(lists)
	for i in lists:
		os.rename('download/'+i,'download/'+str(j)+'.mp4')
		os.system('ffmpeg -ss 00:00:00 -i '+'download/'+str(j)+'.mp4'+' -t 120 downloads/'+str(j)+'.mp4')
		video = VideoFileClip('downloads/'+str(j)+'.mp4')
		audio = video.audio
		audio.write_audiofile('output/'+str(j)+'.mp3')
		j+=1
	zipper.main()
	mailer.main(email)
	return 'Submitted'

if __name__=="__main__":
	app.run()