from flask import *
import scrap
import process
import zipper
import mailer
app = Flask(__name__)
def downloadimages(keyword,number):
    scrap.main(keyword,number)

@app.route('/')
def home(message = " "):
	return render_template("index.html",message=message)


@app.route('/submitted', methods=['POST'])
def submitted():
    keyword = request.form['keyword']
    number = request.form['number']
    email = request.form['email']
    downloadimages(keyword,int(number))
    keyword = '_'.join(keyword.lower().split(' '))
    print('image downloading finished')
    process.main(keyword)
    print('image processing finished')
    zipper.main(keyword)
    print('zipped image folder')
    mailer.main(email)
    print('mailed to '+email)
    return home('Submitted')
if __name__=="__main__":
    app.run()