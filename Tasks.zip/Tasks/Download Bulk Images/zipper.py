import shutil
def main(keyword):
	shutil.make_archive('zipped_images', 'zip', 'downloads/'+keyword)