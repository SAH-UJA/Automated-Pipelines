import os
from PIL import Image

def main(keyword):    
    k = []
    for i in os.walk('downloads/'+keyword):
    	k = i[2]
    	break
    for i in k:
    	im = Image.open('downloads/'+keyword+'/'+i)
    	width, height = im.size
    	newsize = (width//2, height//2)
    	im = im.resize(newsize)
    	im.save('downloads/'+keyword+'/'+i)
    